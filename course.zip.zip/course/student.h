/**
 * @file course.h
 * @author your name (you@domain.com)
 * @brief: typedef for student 
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */

/**
 * @brief Student has a first and last name, which are 50 characters each 
 * they have an id which is 11 characters, and an array for grades and an int for the number of grades
 */
typedef struct _student 
{ 
  char first_name[50];
  char last_name[50];
  char id[11];
  double *grades; 
  int num_grades; 
} Student;

void add_grade(Student *student, double grade);
double average(Student *student);
void print_student(Student *student);
Student* generate_random_student(int grades); 
