/**
 * @file student.c
 * @author your name (you@domain.com)
 * @brief 
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "student.h"

/**
 * @brief Adds a grade to the student's grades 
 * 
 * @param student Takes the student to which the grade needs to be added
 * @param grade Takes the grade that will be added to the student's grades
 */
void add_grade(Student* student, double grade)
{
  // Increases the number of grades by 1
  student->num_grades++;
  //if there is only 1 grade, then an array with memory for one double is created
  if (student->num_grades == 1) student->grades = calloc(1, sizeof(double));
  //otherwise, an array with memory for one more double is created
  else 
  {
    student->grades = 
      realloc(student->grades, sizeof(double) * student->num_grades);
  }
  //returns the updated student
  student->grades[student->num_grades - 1] = grade;
}

/**
 * @brief calculates the average of the students grades
 * 
 * @param student Takes the student whose grades will be averaged
 * @return double returns the average
 */
double average(Student* student)
{
  //if there are no grades, then return 0
  if (student->num_grades == 0) return 0;

  //adds all the grades in the grades array
  double total = 0;
  for (int i = 0; i < student->num_grades; i++) total += student->grades[i];
  //returns the average, which is the total of the grades divided by total number of grades
  return total / ((double) student->num_grades);
}


/**
 * @brief prints the name, id, grades and average of the grades of the student
 * 
 * @param student 
 */
void print_student(Student* student)
{
  printf("Name: %s %s\n", student->first_name, student->last_name);
  printf("ID: %s\n", student->id);
  printf("Grades: ");
  for (int i = 0; i < student->num_grades; i++) 
    printf("%.2f ", student->grades[i]);
  printf("\n");
  printf("Average: %.2f\n\n", average(student));
}

/**
 * @brief generates a random student
 * 
 * @param grades takes a number of grades and uses it to create a new student
 * @return Student* returns a student
 */

Student* generate_random_student(int grades)
{
  //has a random selection of first names to choose from
  char first_names[][24] = 
    {"Shahrzad", "Leonti", "Alexa", "Ricardo", "Clara", "Berinhard", "Denzel",
     "Ali", "Nora", "Malcolm", "Muhammad", "Madhu", "Jaiden", "Helena", "Diana",
     "Julie", "Omar", "Yousef",  "Amir", "Wang", "Li", "Zhang", "Fen", "Lin"};

  // has a random selection of last names to choose from
  char last_names[][24] = 
   {"Chen", "Yang", "Zhao", "Huang", "Brown", "Black", "Smith", "Williams", 
    "Jones", "Miller", "Johnson", "Davis", "Abbas", "Ali", "Bakir", "Ismat", 
    "Khalid", "Wahed", "Taleb", "Hafeez", "Hadid", "Lopez", "Gonzalez", "Moore"};
  
  Student *new_student = calloc(1, sizeof(Student));

  //chooses random names for the first and last name
  strcpy(new_student->first_name, first_names[rand() % 24]);
  strcpy(new_student->last_name, last_names[rand() % 24]);
  
  //creates a random 9 digit student id
  for (int i = 0; i < 10; i++) new_student->id[i] = (char) ((rand() % 10) + 48);
  new_student->id[10] = '\0';

  //adds random grades from 25-75 the number of times specified in the input
  for (int i = 0; i < grades; i++) 
  {
    add_grade(new_student, (double) (25 + (rand() % 75)));
  }

  return new_student;
}