#include "course.h"
#include <stdlib.h>
#include <stdio.h>
 
/**
 * @brief: takes a student and course and adds the student to the given course
 * 
 * @param course: The course to which the student will be added
 * @param student: The student that will be added to the course
 */

void enroll_student(Course *course, Student *student)
{ 
  //increases total number of students by 1
  course->total_students++;
  //if it is the first student, then it creates an array with memory for 1 student
  if (course->total_students == 1) 
  {
    course->students = calloc(1, sizeof(Student));
  }
  //if it is not the first student, then it reallocates memory to hold another student
  else 
  {
    course->students = 
      realloc(course->students, course->total_students * sizeof(Student)); 
  }
  //adds student to the course array
  course->students[course->total_students - 1] = *student;
}

/**
 * @brief: prints name of the course, the course code and all the students that are in the course
 * 
 * @param course 
 */

void print_course(Course* course)
{
  //prints the name, code and total number of students
  printf("Name: %s\n", course->name);
  printf("Code: %s\n", course->code);
  printf("Total students: %d\n\n", course->total_students);
  printf("****************************************\n\n");
  //goes through the list and prints each student
  for (int i = 0; i < course->total_students; i++) 
    print_student(&course->students[i]);
}

/**
 * @brief: takes a course as an input, and goes through the students in that course and  
 * returns the student with the highest average grade
 * 
 * @param course Takes in a course to traverse through
 * @return Student* returns the student with the highest average grade
 */

Student* top_student(Course* course)
{
  //if the course has 0 students, returns NULL
  if (course->total_students == 0) return NULL;
 //initializes student average to 0 and max average to whatever the first student's average is
  double student_average = 0;
  double max_average = average(&course->students[0]);
  Student *student = &course->students[0];
 // traverses through the array, and if a student has an average higher than the previous highest, the top student is updated
  for (int i = 1; i < course->total_students; i++)
  {
    student_average = average(&course->students[i]);
    if (student_average > max_average) 
    {
      max_average = student_average;
      student = &course->students[i];
    }   
  }

  return student;
}

/**
 * @brief Takes the course and the number of students passing in the course and returns an array of the students that are passing the course
 * @param course The course in which teh number of students passing will be counted
 * @param total_passing The number of students that are passing the course
 * @return Student* An array of students that are passing the course
 */

Student *passing(Course* course, int *total_passing)
{
  // initializes count and the array of passing students
  int count = 0;
  Student *passing = NULL;
  
  // traverses through the array and for every student with an average of more than 50, count is incremented
  for (int i = 0; i < course->total_students; i++) 
    if (average(&course->students[i]) >= 50) count++;
  
  //creates an array with enough memory for all the passing students
  passing = calloc(count, sizeof(Student));
  // goes through the array and adds the students that are passing to the passing array
  int j = 0;
  for (int i = 0; i < course->total_students; i++)
  {
    if (average(&course->students[i]) >= 50)
    {
      passing[j] = course->students[i];
      j++; 
    }
  }

  *total_passing = count;

  return passing;
}