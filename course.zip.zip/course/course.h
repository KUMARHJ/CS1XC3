/**
 * @file course.h
 * @author your name (you@domain.com)
 * @brief: typedef for course 
 * @version 0.1
 * @date 2022-04-12
 * 
 * @copyright Copyright (c) 2022
 * 
 */
#include "student.h"
#include <stdbool.h>
 
 /**
  * @brief: course has a name(100 characters), code(10 characters), and an array of students and a number of students
  * 
  */

typedef struct _course 
{
  char name[100];
  char code[10];
  Student *students;
  int total_students;
} Course;

void enroll_student(Course *course, Student *student);
void print_course(Course *course);
Student *top_student(Course* course);
Student *passing(Course* course, int *total_passing);


